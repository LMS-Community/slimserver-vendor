#include <stdio.h>
#include "lpc10.h"


