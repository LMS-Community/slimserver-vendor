//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by gifshow.rc
//
#define IDR_MAINFRAME			128
#define IDD_HELLO_DIALOG		102
#define IDD_ABOUTBOX			103
#define IDS_APP_TITLE			103
#define IDS_HELLO			128
#define IDI_GIFSHOW			128
#define IDC_MYICON			129
#define IDC_GIFSHOW			130

#define IDC_STATIC			-1

#define IDM_EXIT			1000
#define IDM_VIEW_25			1001
#define IDM_VIEW_33			1002
#define IDM_VIEW_50			1003
#define IDM_VIEW_100			1004
#define IDM_VIEW_200			1005
#define IDM_VIEW_300			1006
#define IDM_VIEW_400			1007
#define ID_VIEW_ANIMATE			1008
#define ID_VIEW_FRAME			1009

#define IDM_ABOUT			1100

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
