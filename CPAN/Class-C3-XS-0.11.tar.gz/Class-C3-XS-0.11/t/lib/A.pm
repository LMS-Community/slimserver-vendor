package t::lib::A;
our @ISA = qw//;
1;
