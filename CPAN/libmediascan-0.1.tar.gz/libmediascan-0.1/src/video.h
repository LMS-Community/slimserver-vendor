#ifndef _VIDEO_H
#define _VIDEO_H

MediaScanVideo * video_create(void);

void video_destroy(MediaScanVideo *v);

#endif // _VIDEO_H