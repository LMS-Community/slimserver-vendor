#ifndef _UTIL_H
#define _UTIL_H

int match_file_extension (const char *filename, const char *extensions);

#endif
