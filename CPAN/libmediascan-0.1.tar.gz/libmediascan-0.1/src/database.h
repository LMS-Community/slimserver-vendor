
#ifndef DATABASE_H
#define DATABASE_H

int init_bdb(MediaScan *s);
void reset_bdb(MediaScan *s);

#endif
