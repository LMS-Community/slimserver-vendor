#!/usr/bin/env perl

use strict;
use blib;
use Media::Scan;
use Devel::Peek;

my $paths = [
	'/Volumes/media/DLNA/Video/Movies/Quentin Tarantino',
];

my $s = Media::Scan->new( $paths, {
	#loglevel => MS_LOG_DEBUG,
	async => 0,
	thumbnails => [
		# DLNA
		#{ format => 'JPEG', width => 160, height => 160 }, # for JPEG_TN
		#{ format => 'PNG', width => 160, height => 160 },  # for PNG_TN
		# SP
		#{ format => 'PNG', width => 41, height => 41 },    # jive/baby
		#{ format => 'PNG', width => 40, height => 40 },    # fab4 touch
		# Web UI large thumbnails
		#{ format => 'PNG', width => 100, height => 100 },
	],
	on_result => sub {
	    my $result = shift;
	    
	    warn "Size for " . $result->path . ": " . $result->size . "\n";
	    
	    #my $hash = $result->as_hash;
	    
	    #my $thumbs = $result->thumbnails;
	    
	    #my $tags = $result->tags;
	    #Dump($tags);
	},
	on_error  => sub { },
	on_progress => sub { },
	on_finish => sub { },
} );
