package Media::Scan::Image;

use strict;
use base qw(Media::Scan::Result);

# Implementation is in xs/Image.xs and xs/Result.xs

1;