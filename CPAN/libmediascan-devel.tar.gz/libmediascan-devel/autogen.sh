#!/bin/sh

autoreconf -i

