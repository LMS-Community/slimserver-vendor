#ifndef CONFIG_H
#define CONFIG_H

#undef inline
#define inline _inline

void croak(char *fmt, ...);

#endif