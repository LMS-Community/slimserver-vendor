libtool --mode execute gdb scan_test
